//
// Created by Zhang Yunce on 7/5/2023.
//

#ifndef SRC_OPTIONAL_H
#define SRC_OPTIONAL_H


class optional {

};


#endif //SRC_OPTIONAL_H
